package pb;

import pc.Car;

public class test
{
	public static void main(String[] args)
	{
		Car car1;
		car1 = new Car();
		car1.show();
	}
}