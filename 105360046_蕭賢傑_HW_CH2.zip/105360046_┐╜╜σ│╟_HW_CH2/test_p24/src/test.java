import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class test
{
	public static void main(String[] args)throws IOException
	{
		for(int i = 1; i <= 5; i++)
		{
			System.out.println("��" + i + "�����j��");
		}

		System.out.println("�j�鵲��");
	}
}
