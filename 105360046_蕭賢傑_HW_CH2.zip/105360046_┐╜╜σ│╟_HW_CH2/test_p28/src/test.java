import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class test
{
	public static void main(String[] args)throws IOException
	{
		int i=1;
		do
		{
			System.out.println("��" + i + "�����j��");
			i++;
		}while(i <= 5);

		System.out.println("�j�鵲��");
	}
}
