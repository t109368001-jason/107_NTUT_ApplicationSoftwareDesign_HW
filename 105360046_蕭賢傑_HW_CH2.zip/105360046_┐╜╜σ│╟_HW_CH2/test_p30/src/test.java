import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class test
{
	public static void main(String[] args)throws IOException
	{
		int i,j;
		for(i = 0; i< 5; i++)
		{
			for(j = 0; j < 3; j++)
			{
				System.out.println("i��" + i + ":j�O" + j);
			}
		}
		
		System.out.println("�j�鵲��");
	}
}
